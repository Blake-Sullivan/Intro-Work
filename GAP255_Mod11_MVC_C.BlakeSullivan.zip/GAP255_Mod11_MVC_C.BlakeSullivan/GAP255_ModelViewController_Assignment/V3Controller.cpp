#include "V3Controller.h"

UserChoices CursorSelectionController::GetUserInput(std::vector<std::string> menu, int numItems)
{
    return UserChoices();
}
