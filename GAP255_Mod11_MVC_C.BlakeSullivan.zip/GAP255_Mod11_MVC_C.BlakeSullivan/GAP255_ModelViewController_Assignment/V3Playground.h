#pragma once

#include "Vector3Playground.h"

typedef Vector3Playground<100> V3Playground;

