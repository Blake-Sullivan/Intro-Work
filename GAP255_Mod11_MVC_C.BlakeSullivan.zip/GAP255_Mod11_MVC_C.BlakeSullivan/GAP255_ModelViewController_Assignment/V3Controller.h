#pragma once

#include <iostream>
#include <vector>
#include <conio.h>
#include <Windows.h>

#include "Vector3.h"


// Global variable for exiting the program.
extern bool g_exit = false;

// enum for menu choices.
enum class UserChoices
{
	kAdd = 0,
	kModify = 1,
	kDelete = 2,
	kQuit = 3,
	kCount
};

// MVC: Controller - Base Class.
struct V3Controller {
	virtual std::string ToString() = 0;

	// Controller that works on arrays, takes in a V3Playground object.
	virtual void Update(V3Playground& vectors) = 0;

	// Controller that works on vector<>'s, takes in a vector<Vector3> object.
	virtual void Update(std::vector<Vector3>& vectors) = 0;

	// Prompts user to build a new Vector3 object, returns that object to be added to array / vector<>.
	Vector3 PromptNewVector3()
	{
		std::cout << "Create new Vector3. Enter X, Y, Z values (spaces between): ";
		float tempX = 0;
		float tempY = 0;
		float tempZ = 0;
		std::cin >> tempX;
		std::cin >> tempY;
		std::cin >> tempZ;
		return Vector3{ tempX, tempY, tempZ };
	}

	// Prompts user for an index.
	int PromptIndex()
	{
		std::cout << "Which Vector3 index would you like to change/delete?  ";
		int input;
		std::cin >> input;
		return input;
	}

	// Updates the Vector3 data per user's selection --> for Vector3[] array.
	void ProcessUpdate(UserChoices& choice, V3Playground& vectors)
	{
		// Switch to process the user's choice.
		switch (choice)
		{
		case UserChoices::kAdd:
			vectors.AddData(PromptNewVector3());
			break;
		case UserChoices::kModify:
			vectors.ModifyData(PromptIndex(), PromptNewVector3());
			break;
		case UserChoices::kDelete:
			vectors.RemoveData(PromptIndex());
			break;
		case UserChoices::kQuit:
			std::cout << "quitting\n";
			g_exit = true;
			break;
		default:
			break;
		}
	}

	// Updates the Vector3 data per user's selection --> for vector<Vector3>.
	void ProcessUpdate(UserChoices& choice, std::vector<Vector3>& vectors)
	{
		// Switch to process the user's choice.
		switch (choice)
		{
		case UserChoices::kAdd:
			vectors.emplace_back(PromptNewVector3());
			break;
		case UserChoices::kModify:
			vectors.at(PromptIndex()) = PromptNewVector3();
			break;
		case UserChoices::kDelete:
			vectors.erase(vectors.begin() + PromptIndex());
			break;
		case UserChoices::kQuit:
			std::cout << "quitting\n";
			g_exit = true;
			break;
		default:
			break;
		}
	}
};

// Controller based on specific user number input.
class NumberedCommandController : public V3Controller {
	std::string ToString() override { return "Number Selection Control Scheme."; }

	// Function for obtaining user choice.
	UserChoices GetUserChoice();

	void Update(V3Playground& vectors) override 
	{
		// Obtain the user input - will be casted to appropriate enum.
		UserChoices userSelection = GetUserChoice();

		// Passes both user's choice and the vector array for updating.
		ProcessUpdate(userSelection, vectors);
	}

	void Update(std::vector<Vector3>& vectors) override
	{
		// Obtain the user input - will be casted to appropriate enum.
		UserChoices userSelection = GetUserChoice();

		// Passes both user's choice and the vector array for updating.
		ProcessUpdate(userSelection, vectors);
	}
};


// Controller based on user scroll selection.
class CursorSelectionController : public V3Controller {
private:
	std::vector<std::string>menu { "Add a Vector3.", "Modify a Vector3.", "Delete a Vector3.", "Quit." };

public:
	std::string ToString() override { return "Scroll Selection Control Scheme."; }

	// Function for obtaining user choice, takes in a menu of string options.
	UserChoices GetUserInput(std::vector<std::string> menu);

	void Update(V3Playground& vectors) override
	{		
		// Print the options and return user's choice.
		UserChoices cursorInput = GetUserInput(menu);

		// Passes both user's choice and the vector array for updating.
		ProcessUpdate(cursorInput, vectors);
	}

	void Update(std::vector<Vector3>& vectors) override
	{
		// Print the options and return user's choice.
		UserChoices cursorInput = GetUserInput(menu);

		// Passes both user's choice and the vector array for updating.
		ProcessUpdate(cursorInput, vectors);
	}

};

////////////////////////////////////////////////////////////////////////////////////
////  Selection for Vector3 options - cast from enums.  Also process and return user's choice.
////////////////////////////////////////////////////////////////////////////////////
UserChoices NumberedCommandController::GetUserChoice()
{
	std::cout << "Choose how you would like to change the Vector3 data. Choices are: " << std::endl;
	for (size_t i = 0; i < static_cast<size_t>(UserChoices::kCount); ++i)
	{
		UserChoices iAsRange = static_cast<UserChoices>(i);

		switch (iAsRange)
		{
		case UserChoices::kAdd:
			std::cout << "(" << static_cast<int>(UserChoices::kAdd) << ") Add a Vector3.\n";
			break;
		case UserChoices::kModify:
			std::cout << "(" << static_cast<int>(UserChoices::kModify) << ") Modify a Vector3.\n";
			break;
		case UserChoices::kDelete:
			std::cout << "(" << static_cast<int>(UserChoices::kDelete) << ") Delete a Vector3.\n";
			break;
		case UserChoices::kQuit:
			std::cout << "(" << static_cast<int>(UserChoices::kQuit) << ") Quit.\n";
			break;
		default:
			break;
		}
	}
	int userInput;
	std::cin >> userInput;
	// TODO (BLAKE): make an assertion or other check to ensure user does not make a nonsense choice/input.
	return static_cast<UserChoices>(userInput);
}

////////////////////////////////////////////////////////////////////////////////////
////  Prints Menu options from a vector<string>, then process user scrolling, return user choice.
////////////////////////////////////////////////////////////////////////////////////
UserChoices CursorSelectionController::GetUserInput(std::vector<std::string> menu)
{
	int cursor = 0, textAttrib;
	bool selectionMade = false, needsUpdate = true; // clearscreen first time through
	while (!selectionMade)
	{
		// Only redraw the screen if something has changed, or on the first iteration of while loop.
		if (needsUpdate)
		{
			// TODO (BLAKE):  How to fix the clear screen to still print the "view" after the screen clear??
			system("cls");
			needsUpdate = false;

			// COLOR: Print options using Windows.h functions - 15 = white, 11 = cyan.
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
			std::cout << "Choose how you would like to change the Vector3. Choices are:" << std::endl;
			std::cout << "(navigate with up/down arrow keys, select with enter - ['q' to quit] )" << std::endl << std::endl;
			for (int i = 0; i < menu.size(); i++)
			{
				if (i == cursor)
					textAttrib = 11;
				else
					textAttrib = 15;

				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), textAttrib);
				std::cout << menu.at(i) << std::endl;
			}
		}

		char command = _getch();
		switch (command)
		{
		case -32:	// -32 is returned by all arrow keys =-> do nothing (otherwise "INVALID" always prints).
			break;
		case 80:	// Arrow up.
			cursor++;
			needsUpdate = true;
			break;
		case 72:	// Arrow down.
			cursor--;
			needsUpdate = true;
			break;		
		case 13:	// Enter key.
			selectionMade = true;
			break;
		case 'q':	// Quit.
			cursor = static_cast<int>(UserChoices::kQuit);
			selectionMade = true;
			break;
		default:
			std::cout << "INVALID INPUT!";
			break;
		}

		// Reset cursor if out of scope.
		if (cursor < 0)
			cursor = static_cast<int>(menu.size() - 1);
		else if (cursor > static_cast<int>(menu.size() - 1))
			cursor = 0;
	}
	return static_cast<UserChoices>(cursor);
}