#include <iostream>
#include <string>
#include <vector>

#include "V3Playground.h"
#include "V3View.h"
#include "V3Controller.h"


// Template function which returns user choice from 2 options.
template <typename Option>
Option* GetChosenT(Option* optionA, Option* optionB) {
    int choice = 0;
    std::cout << "Choose option (1 = " << optionA->ToString() << ", 2 = " << optionB->ToString() << "):\n";
    std::cin >> choice;

    if (choice == 1)
        return optionA;
    else 
        return optionB;
}

int main()
{
    // Fill a V3Playground (up to 100 ints) with 5 Vector3 objects.
    V3Playground testPlayground;
    for (float i = 1; i < 6; ++i)
    {
        testPlayground.AddData(Vector3{ i, i, i });
    }
    
    V3View* view = GetChosenT<V3View>(new HorizontalView(), new VerticalView() );
    V3Controller* control = GetChosenT<V3Controller>(new NumberedCommandController(), new CursorSelectionController() );

    while (!g_exit) {
        view->Display(testPlayground);
        system("pause");
        control->Update(testPlayground);
    }
    delete view;
    delete control;

    system("pause"); 
    return 0;
}

/*
// QUESTION:  Is there a way to fill a vector<> with loops? I keep getting conversion erros
std::vector<Vector3> testVectors{ Vector3{ 1, 1, 1 }, Vector3{ 2, 2, 2 }, Vector3{ 3, 3, 3 }, Vector3{ 4, 4, 4 }, Vector3{ 5, 5, 5 } };;
testVectors.reserve(10);
for (size_t i = 0; i < testVectors.size(); ++i)
{
    testVectors.emplace_back(Vector3{ i, i, i });
}
*/