#pragma once

#include <iostream>

/////////////////////////////////////////
// A three-dimensional Euclidean vector.
/////////////////////////////////////////
/*
class Vector3
{
private:
	float m_x;
	float m_y;
	float m_z;

public:
	Vector3()
		: Vector3{ 0,0,0 }
	{}

	Vector3(float x, float y, float z)
		: m_x{ x }
		, m_y{ y }
		, m_z{ z }
	{}

	~Vector3() = default;

	float GetX() const { return m_x; }
	void SetX(float value) { m_x = value; }

	float GetY() const { return m_y; }
	void SetY(float value) { m_y = value; }

	float GetZ() const { return m_z; }
	void SetZ(float value) { m_z = value; }
};
*/

class Vector3
{
private:
	float m_vs[3];

public:
	Vector3() : Vector3{ 0,0,0 } {}
	
	Vector3(float x, float y, float z)
	{
		m_vs[0] = x;
		m_vs[1] = y;
		m_vs[2] = z;
	}
	/*
	// See QUESTION on main tab
	Vector3(size_t x, size_t y, size_t z)
	{
		m_vs[0] = static_cast<float>(x);
		m_vs[1] = static_cast<float>(y);
		m_vs[2] = static_cast<float>(z);
	}
	*/
	float GetX() const { return m_vs[0]; }
	void SetX(float value) { m_vs[0] = value; }

	float GetY() const { return m_vs[1]; }
	void SetY(float value) { m_vs[1] = value; }

	float GetZ() const { return m_vs[2]; }
	void SetZ(float value) { m_vs[2] = value; }

	// Question:  why can't the view class' vector<Vector3> object list see the Print() function?
	void Print()
	{
		std::cout << m_vs[0] << ", " << m_vs[1] << ", " << m_vs[2];
	}

	float operator[](int index) const {
		return m_vs[index];
	}
};
