#pragma once

#include <iostream>

#include "V3Playground.h"

// MVC: View - Base Class.
struct V3View {
	virtual std::string ToString() = 0;

	// Displays a vector<> of Vector3's, takes in a vector<Vector3>.
	virtual void Display(const std::vector<Vector3>& vectors) = 0;

	// Displays an array of Vector3's, takes in a V3Playground object.
	virtual void Display(const V3Playground& vectors) = 0;
};

// MVC: View 1 - Horizontal.
class HorizontalView : public V3View
{
public:
	std::string ToString() override { return "Horizontal View"; }

	// Horizontal vector<> display.
	void Display(const std::vector<Vector3>& vectors) override 
	{
		int tracker = 0;
		for (auto& vector : vectors) {
			std::cout << tracker << ": " << vector.GetX() << ", " << vector.GetY() << ", " << vector.GetZ();
			++tracker;
			std::cout << std::endl;
		}
	}

	// Horizontal array display.
	void Display(const V3Playground& vectors) override
	{
		for (int i = 0; i < vectors.GetDataCount(); ++i) {
			std::cout << i << ": " << vectors.GetDataAtIndex(i)->GetX() << ", " << vectors.GetDataAtIndex(i)->GetY() << ", " << vectors.GetDataAtIndex(i)->GetZ();
			std::cout << std::endl;
		}
	}
};

// MVC: View 2 - Vertical.
class VerticalView : public V3View
{
public:
	std::string ToString() override { return "Vertical View"; }

	// Vertical vector<> display.
	void Display(const std::vector<Vector3>& vectors) override
	{
		// Print Line 1: Vector3 Indices.
		std::cout << "Index: \t";
		for (size_t i = 0; i < vectors.size(); ++i)
		{
			std::cout << i << "\t";
		}
		std::cout << std::endl;

		// Print Line 2: Vector3 X's.
		std::cout << "X: \t";
		for (auto& vector : vectors)
		{
			std::cout << vector.GetX() << "\t";
		}
		std::cout << std::endl;

		// Print Line 3: Vector3 Y's.
		std::cout << "Y: \t";
		for (auto& vector : vectors)
		{
			std::cout << vector.GetY() << "\t";
		}
		std::cout << std::endl;

		// Print Line 3: Vector3 Z's.
		std::cout << "Z: \t";
		for (auto& vector : vectors)
		{
			std::cout << vector.GetZ() << "\t";
		}
		std::cout << std::endl;
	}

	// Vertical array display.
	void Display(const V3Playground& vectors) override
	{
		// Print Line 1: Vector3 Indices.
		std::cout << "Index: \t";
		for (int i = 0; i < vectors.GetDataCount(); ++i)
		{
			std::cout << i << "\t";
		}
		std::cout << std::endl;

		// Print Line 2: Vector3 X's.
		std::cout << "X: \t";
		for (int i = 0; i < vectors.GetDataCount(); ++i)
		{
			std::cout << vectors.GetDataAtIndex(i)->GetX() << "\t";
		}
		std::cout << std::endl;

		// Print Line 3: Vector3 Y's.
		std::cout << "Y: \t";
		for (int i = 0; i < vectors.GetDataCount(); ++i)
		{
			std::cout << vectors.GetDataAtIndex(i)->GetY() << "\t";
		}
		std::cout << std::endl;

		// Print Line 3: Vector3 Z's.
		std::cout << "Z: \t";
		for (int i = 0; i < vectors.GetDataCount(); ++i)
		{
			std::cout << vectors.GetDataAtIndex(i)->GetZ() << "\t";
		}
		std::cout << std::endl;
	}
};

/*
// TODO (Blake):  is there a better way to use an iterator so that I do not need to use a tracker outside the loop
for (auto iter = vectors.begin(); iter != vectors.end(); ++iter)
{
	std::cout << iter << ": " << vectors[0] << "\n";
}
*/